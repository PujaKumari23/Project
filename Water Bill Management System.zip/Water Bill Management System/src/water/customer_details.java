package water;


import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.sql.*;

public class customer_details extends JFrame implements ActionListener{
 
	//class for creating a table  i.e, JTable
    JTable t1;
    JButton b1;
    
    //stringa array for heading
    String x[] = {"Emp Name","Meter No","Address","State","City","Email","Phone"};
    
    //2d array to store data
    String y[][] = new String[20][8];
    int i=0, j=0;
    customer_details(){
        super("Customer Details");
        setSize(1200,650);
        setLocation(120,70);
        
        try{
        	
        	//data printing 
            conn c1  = new conn();
            
            //executes the query and prints the data in array
            String s1 = "select * from emp";
            ResultSet rs  = c1.s.executeQuery(s1);
            while(rs.next()){
                y[i][j++]=rs.getString("name");            //0,1 Fetching data and printing in table 
                y[i][j++]=rs.getString("meter_number");
                y[i][j++]=rs.getString("address");
                y[i][j++]=rs.getString("state");
                y[i][j++]=rs.getString("city");
                y[i][j++]=rs.getString("email");
                y[i][j++]=rs.getString("phone");
                i++;								//i at next row
                j=0;								//col again at 0
            }
            t1 = new JTable(y,x);
            
        }catch(Exception e){
            e.printStackTrace();
        }
        
        
        b1 = new JButton("Print");
        add(b1,"South");
        JScrollPane sp = new JScrollPane(t1);    //in case more data scroll the frame
        add(sp);
        b1.addActionListener(this);
    }
    public void actionPerformed(ActionEvent ae){
        try{
            t1.print();
        }catch(Exception e){}
    }
    
    public static void main(String[] args){
        new customer_details().setVisible(true);
    }
    
}
