package water;



import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.sql.*;

public class Login extends JFrame implements ActionListener{
	//declaring variables globally
    JLabel l,l1,l2,l3;
    JTextField tf1;
    JPasswordField pf2;
    JButton b1,b2;
    JPanel p1,p2,p3,p4;
    Login(){
        super("Login");
        
        
        //defining labels
       
        l1 = new JLabel("Username");
        l2 = new JLabel("Password");
        
        tf1 = new JTextField(15);
        pf2 = new JPasswordField(15);  //15 columns
        
        //imageicon is a class that loads system image
        //setting image size using getSacledInstance
        //defining buttons which will perform action 
        ImageIcon ic1 = new ImageIcon(ClassLoader.getSystemResource("icon/allow.png"));
        Image i1 = ic1.getImage().getScaledInstance(20, 20,Image.SCALE_DEFAULT); 
        b1 = new JButton("Login", new ImageIcon(i1));
        b1.setFont(new Font("monospaced",Font.BOLD,14));
        
        ImageIcon ic2 = new ImageIcon(ClassLoader.getSystemResource("icon/cancel.jpg"));
        Image i2 = ic2.getImage().getScaledInstance(20, 20,Image.SCALE_DEFAULT);
        b2 = new JButton("Cancel",new ImageIcon(i2));
        b2.setFont(new Font("monospaced",Font.BOLD,14));
        
        //performs actions of login and cancel
        b1.addActionListener(this);
        b2.addActionListener(this);


        ImageIcon ic3 = new ImageIcon(ClassLoader.getSystemResource("icon/pop.png"));
        Image i3 = ic3.getImage().getScaledInstance(130,130,Image.SCALE_DEFAULT);
        ImageIcon icc3 = new ImageIcon(i3);
        l3 = new JLabel(icc3);
        
        //in border layout we place components and arrange them by giving directions
        setLayout(new BorderLayout());
        
                
        p1 = new JPanel();
        p2 = new JPanel();
        p3 = new JPanel();
        p4 = new JPanel();
        
        
        
        //l3 added at west i.e, image added
        add(l3,BorderLayout.WEST);
        //inside p2 panel adding 
        
        
        l1.setFont(new Font("monospaced",Font.BOLD,16));
        l2.setFont(new Font("monospaced",Font.BOLD,16));
        add(p2,BorderLayout.CENTER);
        
        p3.add(l1);
        p3.add(tf1);
        p3.add(l2);
        p3.add(pf2);
        add(p3,BorderLayout.CENTER);
        
        //in p4 adding buttons at south login and cancel
        p4.add(b1);
        p4.add(b2);
        add(p4,BorderLayout.SOUTH);
        
        p2.setBackground(Color.WHITE);
        p4.setBackground(Color.WHITE);
        
        //sets size of frame
        //sets location of frame
        //sets visibility
        setSize(440,250);
        setLocation(400,300); 
        setVisible(true);
        

        
    }
    
    //for performing button action
    public void actionPerformed(ActionEvent ae){
        
        try{        
            conn c1 = new conn();
            //retrieves values
            String a  = tf1.getText();
            String b  = pf2.getText();
            //MySql query in q
            String q  = "select * from login where username = '"+a+"' and password = '"+b+"'";
            
            //executing query for data retrieval and result set jumps column to coloumn 
            ResultSet rs = c1.s.executeQuery(q);
            if(rs.next()){
                new Project().setVisible(true);
                this.setVisible(false);
                
            }else{
                JOptionPane.showMessageDialog(null, "Invalid login");
                setVisible(false);
            }
        }catch(Exception e){
            e.printStackTrace();
            System.out.println("error: "+e);
        }
    }
    
    public static void main(String[] args){
        new Login().setVisible(true);
    }

    
}



