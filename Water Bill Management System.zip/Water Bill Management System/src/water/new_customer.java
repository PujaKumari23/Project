package water;



import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.sql.*;
import javax.swing.border.Border;
import javax.swing.border.EmptyBorder;

public class new_customer extends JFrame implements ActionListener{
    JLabel l,l1,l2,l3,l4,l5,l6,l7,l8;
    JTextField t1,t2,t3,t4,t5,t6,t7;
    JButton b1,b2;
    new_customer(){
    	super("New customer");
        setLocation(350,80);
        setSize(700,650);
        
        
        JPanel p = new JPanel();
        //gridlayout - no of rows and columns
        p.setLayout(new GridLayout(9,2,10,10));
        p.setBorder(new EmptyBorder(5, 5, 5, 15));
        p.setBackground(Color.WHITE);
        Border border=BorderFactory.createLineBorder(Color.blue, 2);
        Font font1 = new Font("SansSerif", Font.BOLD, 16);
        
        
        //defining and adding
        
        
        l1 = new JLabel("Name");
        t1 = new JTextField();
        t1.setBorder(border);
        t1.setFont(font1);
        t1.setHorizontalAlignment(JTextField.CENTER); 
        p.add(l1);
        p.add(t1);
        
        l2 = new JLabel("Meter No");
        t2 = new JTextField();
        t2.setBorder(border);
        t2.setFont(font1);
        t2.setHorizontalAlignment(JTextField.CENTER); 
        p.add(l2);
        p.add(t2);
        
        l3 = new JLabel("Address");
        t3 = new JTextField();
        t3.setBorder(border);
        t3.setFont(font1);
        t3.setHorizontalAlignment(JTextField.CENTER); 
        p.add(l3);
        p.add(t3);
        
        l4 = new JLabel("State");
        t4 = new JTextField();
        t4.setBorder(border);
        t4.setFont(font1);
        t4.setHorizontalAlignment(JTextField.CENTER); 
        p.add(l4);
        p.add(t4);
        
        l5 = new JLabel("City");
        t5 = new JTextField();
        t5.setBorder(border);
        t5.setFont(font1);
        t5.setHorizontalAlignment(JTextField.CENTER); 
        p.add(l5);
        p.add(t5);
        
        l6 = new JLabel("Email");
        t6 = new JTextField();
        t6.setBorder(border);
        t6.setFont(font1);
        t6.setHorizontalAlignment(JTextField.CENTER); 
        p.add(l6);
        p.add(t6);
        
        l7 = new JLabel("Phone Number");
        t7 = new JTextField();
        t7.setBorder(border);
        t7.setFont(font1);
        t7.setHorizontalAlignment(JTextField.CENTER); 
        p.add(l7);
        p.add(t7);
        
        b1 = new JButton("Submit");
        b2 = new JButton("Cancel");
        
      
        t7.setBorder(border);
        t7.setFont(font1);
        t7.setHorizontalAlignment(JTextField.CENTER); 
        

        b1.setForeground(Color.WHITE);
        b1.setBackground(Color.BLACK);
        b2.setBackground(Color.BLACK);
        b2.setForeground(Color.WHITE);
        
        p.add(b1);
        p.add(b2);
        setLayout(new BorderLayout());
        
        
        //first components are added into panel and then panel added to center of the screen
        add(p,"Center");
        
        
        //icon image at west
        ImageIcon ic1 = new ImageIcon(ClassLoader.getSystemResource("icon/Person.png"));
        Image i3 = ic1.getImage().getScaledInstance(200, 500,Image.SCALE_DEFAULT);
        ImageIcon ic2 = new ImageIcon(i3);
        l8 = new JLabel(ic2);
        
        
        add(l8,"West");
        //for changing the color of the whole doc
        getContentPane().setBackground(Color.WHITE);
        
        b1.addActionListener(this);
        b2.addActionListener(this);
        
    }
    
    //adding action listener and using sql query inputting into database
    public void actionPerformed(ActionEvent ae){
        
        String a = t1.getText();
        String c = t2.getText();
        String d = t3.getText();
        String e = t4.getText();
        String f = t5.getText();
        String g = t6.getText();
        String h = t7.getText();
        
        //sql query
        String q1 = "insert into emp values('"+a+"','"+c+"','"+d+"','"+e+"','"+f+"','"+g+"','"+h+"')";
        
        try{
            conn c1 = new conn();
            
            //since inserting value using execute update
            c1.s.executeUpdate(q1);
            //after details are added displaying message and printing confirmation
            JOptionPane.showMessageDialog(null,"Customer Created");
            //after work done closing the panel
            this.setVisible(false);
            
            
        }catch(Exception ex){
             ex.printStackTrace();
        }
        
    }
    
    
    public static void main(String[] args){
        new new_customer().setVisible(true);
    }
}
